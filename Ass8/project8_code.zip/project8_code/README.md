# IFN680 Project 8: Extending Tiny NeRF (Group 4)

Karan Rooprai (n12498122), Nhu Hieu Nguyen (n12194778)

## Contents

| File | Purpose |
|---|---|
| `main_report.ipynb` | **Run this for marking.** It loads the saved weights and reproduces every number and figure in the report (Task 3). It has no training loop. |
| `TinyNeRF.ipynb` | The Tutorial 10.4 Tiny NeRF baseline. Its only changes are the shared training budget, a fixed seed, chunked test rendering and saving the weights. Executed. |
| `ExtendedNeRF.ipynb` | Task 1 (view-dependent colour) and Task 2 (coarse/fine hierarchical sampling), plus the two ablation models. Executed. |
| `tinynerf.pth`, `extended_nerf.pth` | Trained weights for the baseline and the extended model. `extended_nerf.pth` holds both the coarse and fine networks. |
| `ablation_no_viewdirs.pth`, `ablation_uniform96.pth` | Ablation A (no view directions) and ablation B (96 uniform samples, no coarse network). |
| `training_history.json`, `training_log.txt` | Per-epoch train and test PSNR and epoch times for all four models. |
| `tiny_nerf_data.npz` | The dataset. Views 100–105 are the held-out test views. |
| `results_summary.json`, `fig_*.png`, `nerf_turntable.gif` | The outputs `main_report.ipynb` produces: the report figures and the 360° "3D movie" (Tiny NeRF on the left, Extended NeRF on the right). |

## How to run

Put all files in one folder and run `main_report.ipynb` from top to bottom. It works on a GPU or a CPU and takes about a minute on a GPU. It needs `torch`, `numpy`, `matplotlib` and `Pillow`.

## Headline results (6 held-out test views)

| Model | PSNR (dB) | SSIM |
|---|---|---|
| Tiny NeRF | 25.41 | 0.893 |
| Extended NeRF | **28.44** | **0.940** |
| A: no view directions | 26.41 | 0.916 |
| B: view-dependent, 96 uniform samples | 28.34 | 0.936 |
